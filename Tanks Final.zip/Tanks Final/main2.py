# Импорт необходимых модулей и инициализация Pygame
import pygame
from random import randint

pygame.init()

# Настройка размеров окна и FPS
WIDTH, HEIGHT = 800, 600  # Ширина и высота окна
FPS = 60  # Количество кадров в секунду

# Создание окна игры
window = pygame.display.set_mode((WIDTH, HEIGHT))
clock = pygame.time.Clock()

# Настройка заголовка окна и значка
pygame.display.set_caption('Танки')  # Заголовок окна
pygame.display.set_icon(pygame.image.load('images/tank1.png'))  # Установка иконки окна

# Загрузка шрифтов
fontUI = pygame.font.Font(None, 30)  # Шрифт для интерфейса
fontBig = pygame.font.Font(None, 70)  # Шрифт для крупных заголовков
fontTitle = pygame.font.Font(None, 140)  # Шрифт для титульного экрана

# Загрузка изображений для блоков, танков, взрывов и бонусов
imgBrick = pygame.image.load('images/block_brick.png')
imgTanks = [pygame.image.load(f'images/tank{i + 1}.png') for i in range(8)]  # Массив изображений танков
imgBangs = [
    pygame.image.load('images/bang1.png'),
    pygame.image.load('images/bang2.png'),
    pygame.image.load('images/bang3.png'),
    pygame.image.load('images/bang2.png'),
    pygame.image.load('images/bang1.png'),
]
imgBonuses = [
    pygame.image.load('images/bonus_star.png'),  # Бонус "звезда"
    pygame.image.load('images/bonus_tank.png'),  # Бонус "дополнительная жизнь"
]

# Загрузка звуковых эффектов
sndShot = pygame.mixer.Sound('sound/shot.wav')  # Звук выстрела
sndDestroy = pygame.mixer.Sound('sound/destroy.wav')  # Звук разрушения
sndDead = pygame.mixer.Sound('sound/dead.wav')  # Звук уничтожения танка
sndLive = pygame.mixer.Sound('sound/live.wav')  # Звук получения жизни
sndStar = pygame.mixer.Sound('sound/star.wav')  # Звук получения бонуса "звезда"
sndEngine = pygame.mixer.Sound('sound/engine.wav')  # Звук двигателя
sndEngine.set_volume(0.2)  # Уменьшение громкости звука двигателя
sndMove = pygame.mixer.Sound('sound/move.wav')  # Звук движения танка
sndMove.set_volume(0.2)  # Уменьшение громкости звука движения

# Загрузка музыкального трека
pygame.mixer.music.load('sound/level_start.mp3')
pygame.mixer.music.play()  # Воспроизведение музыки

# Константы для управления направлениями движения
DIRECTS = [[0, -1], [1, 0], [0, 1], [-1, 0]]  # Вверх, вправо, вниз, влево
TILE = 32  # Размер клетки на поле

# Параметры танков: скорость, урон, задержка выстрела и другие характеристики
MOVE_SPEED = [1, 2, 2, 1, 2, 3, 3, 2]
BULLET_SPEED = [4, 5, 6, 5, 5, 5, 6, 7]
BULLET_DAMAGE = [1, 1, 2, 3, 2, 2, 3, 4]
SHOT_DELAY = [60, 50, 30, 40, 30, 25, 25, 30]

# Создание классов для объектов игры
# Определение класса Tank (танк игрока или ИИ)
class Tank:
    def __init__(self, color, px, py, direct, keysList):
        """
        Инициализация нового объекта Tank (танк).

        Параметры:
        - color: Цвет танка (строка, например, 'blue').
        - px, py: Начальная позиция танка на экране (в пикселях).
        - direct: Начальное направление (0 - вверх, 1 - вправо, 2 - вниз, 3 - влево).
        - keysList: Список клавиш управления (для движения и стрельбы).
        """
        # Добавляем танк в глобальный список объектов игры
        objects.append(self)
        self.type = 'tank'  # Устанавливаем тип объекта (для взаимодействий)

        # Основные характеристики танка
        self.color = color  # Цвет танка
        self.rect = pygame.Rect(px, py, TILE, TILE)  # Прямоугольник, представляющий позицию и размер танка
        self.direct = direct  # Направление танка (0: вверх, 1: вправо, 2: вниз, 3: влево)
        self.moveSpeed = 2  # Скорость движения танка

        # Параметры стрельбы
        self.shotTimer = 0  # Таймер перезарядки (в кадрах)
        self.shotDelay = 60  # Задержка между выстрелами
        self.bulletSpeed = 5  # Скорость полета пули
        self.bulletDamage = 1  # Урон от выстрела
        self.isMove = False  # Флаг, указывающий, двигается ли танк

        self.hp = 5  # Количество очков здоровья танка

        # Клавиши управления (передаются как аргумент keysList)
        self.keyLEFT = keysList[0]  # Клавиша движения влево
        self.keyRIGHT = keysList[1]  # Клавиша движения вправо
        self.keyUP = keysList[2]  # Клавиша движения вверх
        self.keyDOWN = keysList[3]  # Клавиша движения вниз
        self.keySHOT = keysList[4]  # Клавиша стрельбы

        # Уровень танка (отвечает за улучшение характеристик)
        self.rank = 0  # Начальный уровень (0)
        # Загрузка изображения танка в зависимости от уровня и направления
        self.image = pygame.transform.rotate(imgTanks[self.rank], -self.direct * 90)
        self.rect = self.image.get_rect(center=self.rect.center)  # Обновление позиции изображения

    def update(self):
        """
        Обновление состояния танка (вызывается каждый кадр).
        """
        # Обновление изображения танка в зависимости от направления
        self.image = pygame.transform.rotate(imgTanks[self.rank], -self.direct * 90)
        # Уменьшение размеров изображения для визуального эффекта
        self.image = pygame.transform.scale(self.image, (self.image.get_width() - 5, self.image.get_height() - 5))
        self.rect = self.image.get_rect(center=self.rect.center)  # Коррекция позиции

        # Обновление характеристик танка в зависимости от уровня
        self.moveSpeed = MOVE_SPEED[self.rank]
        self.bulletDamage = BULLET_DAMAGE[self.rank]
        self.bulletSpeed = BULLET_SPEED[self.rank]
        self.shotDelay = SHOT_DELAY[self.rank]

        # Сохранение текущей позиции (на случай отката при столкновении)
        oldX, oldY = self.rect.topleft

        # Обработка движения в зависимости от нажатых клавиш
        if keys[self.keyUP]:  # Движение вверх
            self.rect.y -= self.moveSpeed
            self.direct = 0  # Устанавливаем направление
            self.isMove = True  # Указываем, что танк двигается
        elif keys[self.keyRIGHT]:  # Движение вправо
            self.rect.x += self.moveSpeed
            self.direct = 1  # Устанавливаем направление
            self.isMove = True
        elif keys[self.keyDOWN]:  # Движение вниз
            self.rect.y += self.moveSpeed
            self.direct = 2  # Устанавливаем направление
            self.isMove = True
        elif keys[self.keyLEFT]:  # Движение влево
            self.rect.x -= self.moveSpeed
            self.direct = 3  # Устанавливаем направление
            self.isMove = True
        else:
            self.isMove = False  # Если ни одна клавиша движения не нажата

        # Обработка стрельбы
        if keys[
            self.keySHOT] and self.shotTimer == 0:  # Проверяем, нажата ли клавиша стрельбы, и истек ли таймер перезарядки
            dx = DIRECTS[self.direct][0] * self.bulletSpeed  # Определяем скорость пули по оси X
            dy = DIRECTS[self.direct][1] * self.bulletSpeed  # Определяем скорость пули по оси Y
            Bullet(self, self.rect.centerx, self.rect.centery, dx, dy, self.bulletDamage)  # Создаем объект пули
            self.shotTimer = self.shotDelay  # Устанавливаем таймер перезарядки

        # Снижение таймера перезарядки, если он больше нуля
        if self.shotTimer > 0:
            self.shotTimer -= 1

        # Проверка на столкновение с объектами
        for obj in objects:
            if obj != self and obj.type == 'block':  # Если объект - блок
                if self.rect.colliderect(obj):  # Проверяем пересечение прямоугольников
                    self.rect.topleft = oldX, oldY  # Возвращаемся на предыдущую позицию

    def draw(self):
        """
        Отрисовка танка на экране.
        """
        window.blit(self.image, self.rect)  # Рисуем изображение танка на его текущей позиции

    def damage(self, value):
        """
        Нанесение урона танку.

        Параметры:
        - value: Величина урона.
        """
        self.hp -= value  # Уменьшаем количество очков здоровья
        if self.hp <= 0:  # Если здоровье танка упало до нуля
            objects.remove(self)  # Удаляем танк из списка объектов
            sndDead.play()  # Воспроизводим звук уничтожения
            print(self.color, 'is dead')  # Выводим сообщение в консоль


# Класс Bullet (пуля)
class Bullet:
    def __init__(self, parent, px, py, dx, dy, damage):
        """
        Инициализация нового объекта Bullet (пуля).

        Параметры:
        - parent: Родительский объект, выпустивший пулю (танк, например).
        - px, py: Начальная позиция пули (в пикселях).
        - dx, dy: Скорость пули по осям X и Y (в пикселях на кадр).
        - damage: Урон, наносимый пулей при попадании.
        """
        self.parent = parent  # Указываем, кто выпустил пулю (для исключения самоповреждения)
        self.px, self.py = px, py  # Координаты пули
        self.dx, self.dy = dx, dy  # Направление и скорость движения пули
        self.damage = damage  # Урон, который наносит пуля

        bullets.append(self)  # Добавляем пулю в глобальный список пуль
        sndShot.play()  # Воспроизводим звук выстрела

    def update(self):
        """
        Обновление состояния пули (вызывается каждый кадр).
        """
        # Перемещаем пулю в направлении скорости
        self.px += self.dx
        self.py += self.dy

        # Проверяем, вышла ли пуля за границы экрана
        if self.px < 0 or self.px > WIDTH or self.py < 0 or self.py > HEIGHT:
            bullets.remove(self)  # Удаляем пулю из списка, если она вышла за экран
        else:
            # Проверяем столкновения пули с другими объектами
            for obj in objects:
                # Исключаем самоповреждение и объекты, на которые пуля не влияет
                if obj != self.parent and obj.type != 'bang' and obj.type != 'bonus':
                    # Проверяем, попала ли пуля в объект
                    if obj.rect.collidepoint(self.px, self.py):
                        obj.damage(self.damage)  # Наносим урон объекту
                        bullets.remove(self)  # Удаляем пулю из списка
                        Bang(self.px, self.py)  # Создаем эффект взрыва в месте попадания
                        sndDestroy.play()  # Воспроизводим звук разрушения
                        break  # Прекращаем проверку, так как пуля больше не существует

    def draw(self):
        """
        Отрисовка пули на экране.
        """
        pygame.draw.circle(window, 'yellow', (self.px, self.py), 2)  # Рисуем пулю как желтый круг


# Класс Bang (взрыв)
class Bang:
    def __init__(self, px, py):
        """
        Инициализация объекта Bang (взрыв).

        Параметры:
        - px, py: Координаты центра взрыва (в пикселях).
        """
        objects.append(self)  # Добавляем объект взрыва в глобальный список объектов игры
        self.type = 'bang'  # Устанавливаем тип объекта ('bang'), чтобы другие элементы знали, что это взрыв

        self.px, self.py = px, py  # Координаты центра взрыва
        self.frame = 0  # Текущий кадр анимации взрыва (начинается с первого кадра)

    def update(self):
        """
        Обновление состояния взрыва (вызывается каждый кадр).
        """
        self.frame += 0.2  # Увеличиваем кадр анимации (0.2 кадра за каждый игровой цикл)
        if self.frame >= 5:  # Если текущий кадр превысил количество доступных кадров анимации
            objects.remove(self)  # Удаляем взрыв из списка объектов игры

    def draw(self):
        """
        Отрисовка взрыва на экране.
        """
        # Выбираем изображение взрыва, соответствующее текущему кадру (округляем индекс до целого числа)
        img = imgBangs[int(self.frame)]

        # Вычисляем прямоугольник изображения, чтобы центр взрыва совпадал с заданными координатами
        rect = img.get_rect(center=(self.px, self.py))

        # Отображаем изображение взрыва на игровом окне
        window.blit(img, rect)


# Класс Block (блок-препятствие)
class Block:
    def __init__(self, px, py, size):
        """
        Инициализация объекта Block (блок-препятствие).

        Параметры:
        - px, py: Координаты верхнего левого угла блока (в пикселях).
        - size: Размер стороны блока (в пикселях).
        """
        objects.append(self)  # Добавляем блок в глобальный список объектов игры.
        self.type = 'block'  # Устанавливаем тип объекта ('block').

        # Создаем прямоугольник блока с указанными координатами и размерами.
        self.rect = pygame.Rect(px, py, size, size)
        self.hp = 1  # Устанавливаем изначальное количество очков прочности блока.

    def update(self):
        """
        Метод обновления блока (вызывается каждый кадр).
        Здесь блок остается статичным, поэтому ничего не происходит.
        """
        pass  # Блок не меняет своего состояния, так как он статичен.

    def draw(self):
        """
        Метод отрисовки блока на экране.
        """
        # Отображаем изображение блока (кирпич) на позиции блока.
        window.blit(imgBrick, self.rect)

    def damage(self, value):
        """
        Метод нанесения урона блоку.

        Параметры:
        - value: Значение урона, которое получает блок.
        """
        self.hp -= value  # Уменьшаем здоровье блока на величину урона.
        if self.hp <= 0:  # Если здоровье блока меньше или равно 0,
            objects.remove(self)  # Удаляем блок из списка объектов.


# Класс Bonus (бонус на игровом поле)
class Bonus:
    def __init__(self, px, py, bonusNum):
        """
        Инициализация объекта Bonus (бонус).

        Параметры:
        - px, py: Координаты центра бонуса (в пикселях).
        - bonusNum: Номер бонуса (определяет тип бонуса).
        """
        objects.append(self)  # Добавляем бонус в глобальный список объектов игры.
        self.type = 'bonus'  # Устанавливаем тип объекта ('bonus').

        # Позиция бонуса.
        self.px, self.py = px, py
        self.bonusNum = bonusNum  # Тип бонуса: 0 - повышение уровня, 1 - добавление здоровья.
        self.timer = 600  # Таймер времени жизни бонуса (в кадрах).

        # Устанавливаем изображение бонуса в зависимости от его типа.
        self.image = imgBonuses[self.bonusNum]
        # Создаем прямоугольник, соответствующий изображению бонуса.
        self.rect = self.image.get_rect(center=(self.px, self.py))

    def update(self):
        """
        Обновление состояния бонуса.
        """
        # Уменьшаем таймер на 1 с каждым кадром.
        if self.timer > 0:
            self.timer -= 1  # Если таймер больше 0, продолжаем уменьшать.
        else:
            objects.remove(self)  # Если таймер истек, удаляем бонус из списка объектов.

        # Проверяем столкновение бонуса с другими объектами.
        for obj in objects:
            # Если объект - танк, и его прямоугольник пересекается с бонусом.
            if obj.type ==  'tank' and self.rect.colliderect(obj.rect):
                if self.bonusNum == 0:  # Тип бонуса 0: Повышение уровня танка.
                    # Увеличиваем ранг танка, если он не достиг максимума.
                    if obj.rank < len(imgTanks) - 1:
                        obj.rank += 1  # Увеличиваем ранг танка.
                        sndStar.play()  # Проигрываем звук получения звезды.
                        objects.remove(self)  # Удаляем бонус.
                        break  # Завершаем цикл, чтобы избежать повторного выполнения.
                elif self.bonusNum == 1:  # Тип бонуса 1: Добавление здоровья.
                    obj.hp += 1  # Увеличиваем здоровье танка.
                    sndLive.play()  # Проигрываем звук получения жизни.
                    objects.remove(self)  # Удаляем бонус.
                    break  # Завершаем цикл.

    def draw(self):
        """
        Отрисовка бонуса на игровом поле.
        """
        # Бонус мерцает (показывается только в половине кадров).
        if self.timer % 30 < 15:
            window.blit(self.image, self.rect)  # Отображаем изображение бонуса.


# Списки для управления объектами и пулями в игре.
bullets = []  # Список всех пуль.
objects = []  # Список всех игровых объектов.

# Создание двух танков-игроков с заданными параметрами.
tank1 = Tank('white', 50, 50, 1, (pygame.K_a, pygame.K_d, pygame.K_w, pygame.K_s, pygame.K_SPACE))  # Синий танк.
tank2 = Tank('red', 700, 500, 3,
             (pygame.K_LEFT, pygame.K_RIGHT, pygame.K_UP, pygame.K_DOWN, pygame.K_RETURN))  # Красный танк.

# Генерация 100 блоков на игровом поле.
for _ in range(100):
    while True:
        # Случайные координаты блока с привязкой к сетке TILE.
        x = randint(0, WIDTH // TILE - 1) * TILE
        y = randint(1, HEIGHT // TILE - 1) * TILE
        rect = pygame.Rect(x, y, TILE, TILE)  # Прямоугольник для проверки коллизии.

        # Проверка, не пересекается ли новый блок с существующими объектами.
        fined = False
        for obj in objects:
            if rect.colliderect(obj):
                fined = True  # Если пересекается, помечаем и продолжаем генерацию.
        if not fined:  # Если пересечений нет, блок создается.
            break

    Block(x, y, TILE)  # Создаем новый блок.

# Инициализация таймеров.
bonusTimer = 180  # Таймер для создания бонуса.
timer = 0  # Общий игровой таймер.
isMove = False  # Флаг движения танков.
isWin = False  # Флаг состояния победы.
y = 0  # Смещение текста "ТАНКИ" при появлении.

# Основной игровой цикл.
play = True
while play:
    # Обработка событий (например, выход из игры).
    for event in pygame.event.get():
        if event.type == pygame.QUIT:  # Если событие выхода, завершаем цикл.
            play = False

    keys = pygame.key.get_pressed()  # Получаем состояние клавиш.

    # Логика таймера движения и звуковых эффектов.
    timer += 1  # Увеличиваем общий таймер.
    if timer >= 260 and not isWin:  # Если игра не завершена и таймер достаточный:
        if oldIsMove != isMove:  # Проверяем изменение состояния движения.
            if isMove:  # Если танк движется:
                sndMove.play()  # Проигрываем звук движения.
                sndEngine.stop()  # Останавливаем звук двигателя.
            else:  # Если танк не движется:
                sndMove.stop()
                sndEngine.play(-1)  # Проигрываем звук двигателя в цикле.

    oldIsMove = isMove  # Запоминаем предыдущее состояние движения.
    isMove = False
    # Проверка, движется ли хотя бы один танк.
    for obj in objects:
        if obj.type == 'tank':
            isMove = isMove or obj.isMove

    # Таймер создания бонусов.
    if bonusTimer > 0:
        bonusTimer -= 1
    else:
        # Создаем бонус на случайных координатах.
        Bonus(randint(50, WIDTH - 50), randint(50, HEIGHT - 50), randint(0, len(imgBonuses) - 1))
        bonusTimer = randint(120, 240)  # Перезапускаем таймер.

    # Обновление состояния всех объектов.
    for bullet in bullets:
        bullet.update()  # Обновление пуль.
    for obj in objects:
        obj.update()  # Обновление игровых объектов.

    # Отрисовка игрового поля.
    window.fill('black')  # Заполняем фон черным цветом.
    for bullet in bullets:
        bullet.draw()  # Отрисовка всех пуль.
    for obj in objects:
        obj.draw()  # Отрисовка всех объектов.

    # Отображение информации о танках (здоровье, ранг).
    i = 0
    for obj in objects:
        if obj.type == 'tank':
            # Отрисовка фона с цветом танка.
            pygame.draw.rect(window, obj.color, (5 + i * 70, 5, 22, 22))

            # Ранг танка.
            text = fontUI.render(str(obj.rank), 1, 'black')
            rect = text.get_rect(center=(5 + i * 70 + 11, 5 + 11))
            window.blit(text, rect)

            # Здоровье танка.
            text = fontUI.render(str(obj.hp), 1, obj.color)
            rect = text.get_rect(center=(5 + i * 70 + TILE, 5 + 11))
            window.blit(text, rect)
            i += 1

    # Проверка оставшихся танков.
    t = 0  # Счетчик оставшихся танков.
    for obj in objects:
        if obj.type == 'tank':
            t += 1
            tankWin = obj  # Последний оставшийся танк.

    # Условие победы.
    if t == 1 and not isWin:
        isWin = True  # Устанавливаем флаг победы.
        timer = 1000  # Устанавливаем таймер завершения игры.

    # Отображение начального экрана.
    if timer < 260:
        y += 2  # Анимация текста.
        pygame.draw.rect(window, 'black', (WIDTH // 2 - 300, HEIGHT // 2 - 200 + y, 600, 250))
        pygame.draw.rect(window, 'orange', (WIDTH // 2 - 300, HEIGHT // 2 - 200 + y, 600, 250), 3)
        text = fontTitle.render('Т А Н К И', 1, 'white')
        rect = text.get_rect(center=(WIDTH // 2, HEIGHT // 2 - 100 + y))
        window.blit(text, rect)
        text = fontBig.render('ОДИН НА ОДИН', 1, 'white')
        rect = text.get_rect(center=(WIDTH // 2, HEIGHT // 2 - 20 + y))
        window.blit(text, rect)

    # Отображение экрана победителя.
    if t == 1:
        text = fontBig.render('ПОБЕДИЛ', 1, 'white')
        rect = text.get_rect(center=(WIDTH // 2, HEIGHT // 2 - 100))
        window.blit(text, rect)

        # Отображение цвета победителя.
        pygame.draw.rect(window, tankWin.color, (WIDTH // 2 - 100, HEIGHT // 2, 200, 200))

    # Воспроизведение звуков победы.
    if isWin and timer == 1000:
        sndMove.stop()
        sndEngine.stop()

        pygame.mixer.music.load('sound/level_finish.mp3')  # Загрузка музыки завершения уровня.
        pygame.mixer.music.play()  # Воспроизведение музыки.

    pygame.display.update()  # Обновление экрана.
    clock.tick(FPS)  # Ограничение FPS.

pygame.quit()  # Завершение игры.
